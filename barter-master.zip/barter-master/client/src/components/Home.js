import React from 'react';

const Home = () => {
  return <div style={{
    "margin": "center",
    "textAlign": "center",
    "padding": "280px 0",
    "width": "50 %",
    "border": "3px solid green",
"    padding": "10px"
  }}>
    <h1>Welcome to Barter APP</h1>  
  </div>;
};

export default Home;
